import styles from "../styles/Card.module.css";

const Card = ({ suit, value, className }) => {
  return (
    <div className={`${styles.card} ${styles[className]}`}>
      <span>{value}</span>
      <span>{suit}</span>
    </div>
  );
};

export default Card;
