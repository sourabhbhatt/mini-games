import { useSelector } from "react-redux";
import styles from "../styles/ScoreBoard.module.css";

const ScoreBoard = () => {
  const players = useSelector((state) => state.game.players);

  return (
    <div>
      <div className={styles.scoreboard}>
        <div className={styles.team}>
          <h3>{"team A"}</h3>
          <p>{"0"}</p>
        </div>
        <div className={styles.team}>
          <h3>{"team B"}</h3>
          <p>{"0"}</p>
        </div>
        {players.map((player) => (
          <div key={player.id}>
            {player.name}: {player.score}
          </div>
        ))}
      </div>
    </div>
  );
};

export default ScoreBoard;
